from django.db import models
from djongo.storage import GridFSStorage
from django.conf import settings
from namespace.models import Namespace
from django.core.files.storage import FileSystemStorage
from django.conf import settings
# Create your models here.

grid_fs_storage = FileSystemStorage(location=settings.MEDIA_ROOT)



class Filespace(models.Model):
    namespace_id = models.CharField(max_length=30)
    user_id = models.IntegerField(default=1)
    filespace_id = models.CharField(primary_key=True,max_length=30)
    file_name = models.CharField(max_length=30)
    file = models.FileField(upload_to='sample_docs',storage=grid_fs_storage)
    processed = models.BooleanField(default=False)
    exclude  = models.IntegerField(default=0)


    def __str__(self):
        return self.filespace_id

    class Meta:
        ordering = ('filespace_id',)
