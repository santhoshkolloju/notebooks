from django.contrib import admin
from django.urls import path
from .views import filespacePage,upload,download

urlpatterns = [
    path('', filespacePage),
    path("/upload",upload),
    path("/download",download)
    #path("/delete",delete),
    #path("/rename",rename)
]
