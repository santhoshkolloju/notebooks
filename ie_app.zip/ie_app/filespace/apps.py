from django.apps import AppConfig


class FilespaceConfig(AppConfig):
    name = 'filespace'
