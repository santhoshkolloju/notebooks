var endpoint = "/filespace/download?namespace_id="+nid+"&filespace_id="+fid;
	console.log()

    function loadPDF() {
        // Clear the PDF container
        pdfContainer.innerHTML = '';

        // Endpoint URL
        var endpoint = "/filespace/download?namespace_id="+nid+"&filespace_id="+fid;

        // Create an iframe element
        var iframe = document.createElement('iframe');

        // Set attributes for the iframe
        iframe.src = endpoint; // Set the src attribute to the endpoint URL
        iframe.width = "100%"; // Set the width to 100% of its container
        iframe.height = "600px"; // Set the height to 600 pixels

        // Append the iframe to the PDF container div
        pdfContainer.appendChild(iframe);
    }

    // Load PDF on initial page load
    loadPDF();

})