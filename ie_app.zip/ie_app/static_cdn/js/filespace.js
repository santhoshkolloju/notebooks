$(document).ready(function(){

  $(".namespace").children('div').css("background-color", "#ea7db2") //mark the colour for current page

  $(".close-icon-left").on("click", function(e) {

    $(".add-filespace-panel").css({
      right: "-23%",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    });
    $(".left-pointer").css({
      display: "flex",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    })



  }) //close icon

  $(".left-pointer").on("click", function(e) {
    $(".left-pointer").css({
      display: "none",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    })
    $(".add-filespace-panel").css({
      right: "0%",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    })


  }) //left pointer click


  $(".file").change(function(event){
		$("#upload_form").ajaxSubmit({

      success: function(data) {

        if (data == "success") {
          $("#snackbar").html("File upload successful refresing page now")
          $("#snackbar").addClass("show");
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);
          window.location.href = "/filespace?namespace_id="+$("#upload-param-1").val()+"&docspace_name="+$("#upload-param-2").val()
        } else if (data == "duplicate") {
          $("#snackbar").addClass("show");
          $("#snackbar").html("File with same name already exists in the database please choose another name")
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);
        }



      } //success


    })

	}); //selecting a file event

  $(".expand").hover(
    function() {
      $(this).find(".namespace-options").css({
        "display": "block",
        transition: 'all 1s ease-in-out',
        WebkitTransition: 'all 1s ease-in-out'
      })
    },
    function() {
      $(this).find(".namespace-options").css({
        "display": "none",
        transition: 'all 1s ease-in-out',
        WebkitTransition: 'all 1s ease-in-out'
      })
    }
  ); //expand the folder options


 $("#extract_info").click(function(){
  var namespace_id = $("#upload-param-1").val()
  var docspace_id = $("#upload-param-2").val()
  window.location.href = "/vqa?namespace_id="+$("#upload-param-1").val()+"&docspace_name="+$("#upload-param-2").val()

 })//extract_info



})//document ready close


