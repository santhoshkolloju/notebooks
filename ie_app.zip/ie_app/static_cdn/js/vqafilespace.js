// Function to get CSRF token from cookie
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            // Check if the cookie name matches the CSRF token cookie name
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}




function clearQuestionContainer() {
    var container = document.getElementById('questionContainer');
    container.innerHTML = ''; // Clear the contents of the container
}

function addQuestionFromData(entity,rowNum) {
    var container = document.getElementById('questionContainer');
    var newRow = document.createElement('div');
    newRow.className = 'dynamic-row question-row-' + rowNum;

    newRow.innerHTML = `
    <div class="delete-container">
      <div class="option-set">
          <div class="row">
              <div class="col-3">
                  <input type="text" class="form-control" placeholder="Entity Name" value="${entity.entity_name}">
              </div>
              <div class="col-9">
                  <input type="text" class="form-control" placeholder="Question" style='width:90%' value="${entity.entity_question}">
              </div>
              <div class="col-3" style="padding-top:5px;">
                  <button type="button" class="btn btn-success" style='width:100%;font-size: 15px;'>
                      Gen Answer<span class="badge text-bg-secondary"></span>
                  </button>
              </div>
              <div class="col-9" style="padding-top:5px;">
                  <input type="text" class="form-control" placeholder="Answer" style='width:90%' value="${entity.entity_answer}">
              </div>
          </div>
      </div>
      <i class="fas fa-trash-alt delete-btn" onclick="deleteOption(this)"></i>
      <i class="fas fa-play run-btn" onclick="runML(this)"></i>
   </div>
    `;

    container.appendChild(newRow); // Append the new row to the container
}


function getEntitiesAndAddQuestions(fid) {


    var filespace_id = fid
    var csrftoken = getCookie('csrftoken');

    // AJAX request to fetch entities
    $.ajax({
        type: "POST",
        url: "/vqa/get_entities",
        headers: {
                    "X-CSRFToken": csrftoken
                },
        data: {
            filespace_id: filespace_id
        },
        success: function(response) {
            if (response.status === "success") {
                clearQuestionContainer(); // Clear the container
                var entities = response.data;
                //alert(entities)
                entities.forEach(function(entity, index) {
                    addQuestionFromData(entity, index); // Pass index as rowNum
                });
            } else {
                console.error("Error:", response.message);
            }
        },
        error: function(xhr, status, error) {
            console.log("AJAX Error:", error);
        }
    });
}



$(document).ready(function(){


var data_namespace_id = ''
var data_file_id = ''

$("#nav-documents-tab").on("click",function(){

	$("#add_qstn_btn").css("display","none")

})


$("#nav-entities-tab").on("click",function(){

	$("#add_qstn_btn").css("display","block")

})

$(".view_pdf").on("click",function(){
    var pdfContainer = document.getElementById('pdfContainer');
	nid = $(this).attr("data-namespace-id")
	fid = $(this).attr('data-file-id')
    data_namespace_id = nid
    data_file_id = fid

    function loadPDF() {
        // Clear the PDF container
        pdfContainer.innerHTML = '';

        // Endpoint URL
        var endpoint = "/filespace/download?namespace_id="+nid+"&filespace_id="+fid;

        // Create an iframe element
        var iframe = document.createElement('iframe');

        // Set attributes for the iframe
        iframe.src = endpoint; // Set the src attribute to the endpoint URL
        iframe.width = "100%"; // Set the width to 100% of its container
        iframe.height = "680px"; // Set the height to 600 pixels

        // Append the iframe to the PDF container div
        pdfContainer.appendChild(iframe);
    }

    // Load PDF on initial page load
    loadPDF();
    $("#nav-entities-tab").click()

    getEntitiesAndAddQuestions(fid)







});


    $("#save-entities-db").on("click",function(){
        //alert(data_namespace_id)
        //alert(data_file_id)
        var container = document.getElementById('questionContainer');
        var questions = [];

        // Iterate over each question row
        container.querySelectorAll('.dynamic-row').forEach(function(row) {
            var entityName = row.querySelector('input[placeholder="Entity Name"]').value;
            var question = row.querySelector('input[placeholder="Question"]').value;
            var answer = row.querySelector('input[placeholder="Answer"]').value;

            // Create a JavaScript object for each question
            var questionData = {
                entity_name: entityName,
                entity_question: question,
                entity_answer: answer
            };

            // Push the question object to the questions array
            questions.push(questionData);
        });

        // Convert the array of questions to JSON string
        var jsonData = JSON.stringify(questions);

        // Perform further actions with jsonData, such as sending it via AJAX
        //alert(jsonData);
        var csrftoken = getCookie('csrftoken');
        $.ajax({
                type: "POST",
                url: "/vqa/store_entities",
                headers: {
                    "X-CSRFToken": csrftoken
                },
                data: {
                    namespace_id: data_namespace_id,
                    filespace_id: data_file_id,
                    entities: jsonData
                },
                success: function(data) {
                    if (data == "success") {
                          $("#snackbar").html("Uploading entities successful, refresing page now")
                          $("#snackbar").addClass("show");
                          setTimeout(function() {
                            $("#snackbar").removeClass("show");
                          }, 3000); 
                    }
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error(xhr.responseText);
                }
        });






    });




	

	











})//document ready




