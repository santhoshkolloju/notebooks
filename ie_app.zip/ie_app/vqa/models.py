from django.db import models
from djongo.storage import GridFSStorage
from django.conf import settings
from namespace.models import Namespace
# Create your models here.
from django.core.files.storage import FileSystemStorage

grid_fs_storage = FileSystemStorage(location=settings.MEDIA_ROOT)



class VQAFeedback(models.Model):
	namespace_id = models.CharField(max_length=30)
	user_id = models.IntegerField(default=1)
	filespace_id = models.CharField(max_length=30)
	entity_name = models.CharField(max_length=30)
	entity_question = models.CharField(max_length=100)
	entity_answer = models.CharField(max_length=100)

	def __str__(self):
	    return self.entity_name
