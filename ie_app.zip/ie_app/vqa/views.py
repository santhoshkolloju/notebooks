

from django.shortcuts import render
from django.shortcuts import render,HttpResponse,redirect
from filespace.models import Filespace
from django.template.defaultfilters import slugify
from djongo.storage import GridFSStorage
from django.conf import settings
from wsgiref.util import FileWrapper
from django.http import FileResponse
from .models import VQAFeedback
from django.http import JsonResponse
import json
from django.core.files.storage import FileSystemStorage
from django.conf import settings

grid_fs_storage = FileSystemStorage(location=settings.MEDIA_ROOT)


def VQAFileSpacePage(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        namespace_id = request.GET['namespace_id']
        docspace_name = request.GET['docspace_name']
        if docspace_name.strip()=="":
            docspace_name = Namespace.objects.get(namespace_id=namespace_id).name
        filespaces = Filespace.objects.filter(namespace_id = namespace_id)
        return render(request , "vqafilespace.html", {"filespaces":filespaces,"namespace_id":namespace_id,
            "docspace_name":docspace_name})


def StoreEntities(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == 'POST':
        user_id = request.user.id
        namespace_id = request.POST.get('namespace_id')
        filespace_id = request.POST.get('filespace_id')
        entities = json.loads(request.POST.get('entities'))

        already_present = VQAFeedback.objects.filter(filespace_id = filespace_id).count()>0
        if already_present:
            VQAFeedback.objects.filter(filespace_id = filespace_id).delete()
        for obj in entities:
            entity_name = obj['entity_name']
            entity_question = obj['entity_question']
            entity_answer = obj['entity_answer']
            ent_instance = VQAFeedback(
                                        user_id = user_id,
                                        filespace_id = filespace_id,
                                        namespace_id= namespace_id,
                                        entity_name = entity_name,
                                        entity_answer = entity_answer,
                                        entity_question = entity_question

                                        )
            ent_instance.save()
        return HttpResponse("success")



def getEntities(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == 'POST':
        user_id = request.user.id
        filespace_id = request.POST.get('filespace_id')
        entities = VQAFeedback.objects.filter(user_id = user_id,filespace_id=filespace_id)
        output = []
        for ent in entities:
            output.append({
                "entity_name":ent.entity_name,
                "entity_answer":ent.entity_answer,
                "entity_question":ent.entity_question
                })
        return JsonResponse({"status": "success", "data": output})
    else:
        return JsonResponse({"status": "error", "message": "Invalid request method"})






