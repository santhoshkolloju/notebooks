from django.contrib import admin
from django.urls import path
from .views import VQAFileSpacePage,StoreEntities,getEntities

urlpatterns = [
    path('', VQAFileSpacePage),
    path('/store_entities',StoreEntities),
    path('/get_entities',getEntities)
    
]