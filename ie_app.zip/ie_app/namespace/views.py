from django.shortcuts import render,redirect,HttpResponse
from .models import Namespace
from django.template.defaultfilters import slugify
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def namespacePage(request):
    if not request.user.is_authenticated:
        return redirect("/")
    else:
        user_id = request.user.id
        try:
            public = request.GET['public']
        except:
            public = 0
        if int(public) == 0:
            user = User.objects.get(pk=user_id)
            namespaces = Namespace.objects.filter(user_id = user_id)
            return render(request , "namespace.html", {"namespaces":namespaces})
        else:
            #console.log("Public namespaces")
            namespaces = Namespace.objects.filter(type_of_space = "public").exclude(user_id = user_id)
            return render(request , "namespace.html", {"namespaces":namespaces})


def create(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        user_id = request.user.id
        name = request.POST['doc-space-name']
        slug = slugify(name)
        print("slug",slug)
        nametype = request.POST['nametype']
        already_present = Namespace.objects.filter(namespace_id = slug).count()>0
        if already_present:
            return HttpResponse("duplicate")
        else:
            n1 = Namespace(user_id = user_id, namespace_id = slug, name=name, type_of_space=nametype)
            n1.save()
            return HttpResponse("success")

def delete(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        id = request.GET['namespace_id']
        nm = Namespace.objects.filter(namespace_id=id)
        nm.delete()
        return HttpResponse("success")

def rename(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        id = request.GET['namespace_id']
        update_name = request.GET['up_name']
        nm = Namespace.objects.get(namespace_id=id)
        nm.name = update_name
        nm.save()
        return HttpResponse("success")
