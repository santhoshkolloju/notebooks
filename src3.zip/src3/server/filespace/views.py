from django.shortcuts import render
from django.shortcuts import render,HttpResponse,redirect
from .models import Filespace
from django.template.defaultfilters import slugify
from djongo.storage import GridFSStorage
from django.conf import settings
from wsgiref.util import FileWrapper
from django.http import FileResponse
grid_fs_storage = GridFSStorage(collection='myfiles', base_url=''.join([settings.BASE_DIR, 'myfiles/']))


# Create your views here.

def filespacePage(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        namespace_id = request.GET['namespace_id']
        docspace_name = request.GET['docspace_name']
        if docspace_name.strip()=="":
            docspace_name = Namespace.objects.get(namespace_id=namespace_id).name
        filespaces = Filespace.objects.filter(namespace_id = namespace_id)
        return render(request , "filespace.html", {"filespaces":filespaces,"namespace_id":namespace_id,
            "docspace_name":docspace_name})

def upload(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        if request.method == "POST":
            user_id = request.user.id
            namespace_id = request.POST['namespace_id']
            docspace_name = request.POST['docspace_name']
            myfile = request.FILES['file']
            slug = slugify(myfile.name)
            already_present = Filespace.objects.filter(filespace_id = slug).count()>0
            if already_present:
                return HttpResponse("duplicate")
            else:

                fil_instance = Filespace(
                                        user_id = user_id,
                                        filespace_id = slug,
                                        file_name = myfile.name,
                                        namespace_id= namespace_id,
                                        file = myfile)
                fil_instance.save()
                #return redirect("/filespace?namespace_id="+namespace_id+"&docspace_name="+docspace_name)
                return HttpResponse("success")

def download(request):
	if request.method == "GET":
		filespace_id = request.GET['filespace_id']
		namespace_id = request.GET['namespace_id']
		fobj = Filespace.objects.get(filespace_id=filespace_id)
		filename = str(fobj.file).split("/")[-1]
		response = HttpResponse(FileWrapper(grid_fs_storage._open("sample_docs/"+filename)),
							content_type = 'application/pdf')
		response['Content-Disposition'] = 'inline'
		return response
