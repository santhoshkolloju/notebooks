from django.shortcuts import render,redirect,HttpResponse
from elasticsearch import Elasticsearch
import json
from .models import Question,Context
from filespace.models import Filespace
from namespace.models import Namespace
from django.core.paginator import Paginator
from bs4 import BeautifulSoup
import random
from django.db.models import Q
import tensorflow as tf
from transformers import pipeline
import tensorflow_hub as hub
model_qsim = hub.load("/Users/santhoshkolloju/Desktop/HelloDoc_Updated/QuestionGeneration/universal-sentence-encoder_4/")

#model_pass = hub.load("/Users/santhoshkolloju/Desktop/HelloDoc_Updated/QuestionGeneration/GPT-2/universal-sentence-encoder-qa_3/")
model_mc = pipeline('question-answering')

def embed_text(text):
    vectors = model_qsim(text)
    return [vector.numpy().tolist() for vector in vectors]

es = Elasticsearch(hosts=['127.0.0.1:9200'])
indices = list(es.indices.get_alias().keys())
indices =  [idx for idx in indices if "_que" in idx]
indices_chunk = [idx for idx in indices if "_chunk" in idx]
print(indices)
paginator = None
# Create your views here.


def get_answer_para_tags(context,html):
        print("context",context)
        soup = BeautifulSoup(html.replace("\n",""))
        lines = context.split("\n")
        if lines[0].strip() == "":
            lines = lines[1:]
        if lines[-1].strip() == "":
            lines = lines[:-1]
        print(lines)
        firstline = "".join(lines[0].strip().split(" "))
        idx = [i for i,p in enumerate(soup.findAll('p')) if (firstline in "".join(p.text.strip().split()))]
        if len(idx) == 1:
            tags =[]
            for i in range(len(lines)):
                tags.append(idx[0]+1+i)
            return tags
        elif len(idx) > 1:
            paras = soup.findAll('p')
            tags = []
            secondline = "".join(lines[1].strip().split(" "))
            for id in idx:
                if secondline in "".join(paras[id+1].text.strip().split()):
                    tags = []
                    for i in range(len(lines)):
                        tags.append(id+1+i)
                    return tags
            return []
        else:
            return []

def get_answer_para_tags_updated_ans(updated_ans,html):
    soup = BeautifulSoup(html.replace("\n",""))
    paras_text = [p.text.strip() for i,p in enumerate(soup.findAll('p'))]
    tags = []
    start = -1
    for i,p in enumerate(paras_text):
        print(updated_ans)
        if updated_ans=="":
            break
        if p in updated_ans:
            if start==-1:
                temp = updated_ans.split(p)
                if len(temp)==2:
                    if temp[0] == "":
                        if (paras_text[i+1] in temp[1]) or (temp[1] in paras_text[i+1]):
                            start = i
                            tags.append(str(i+1))
                            updated_ans = updated_ans.replace(p,"")
                    else:
                        if ((paras_text[i+1] in temp[1]) or (temp[1] in paras_text[i+1])) and ((paras_text[i-1] in temp[0]) or (temp[0] in paras_text[i-1])):
                            start = i
                            tags.extend([str(i),str(i+1)])
                            updated_ans = updated_ans.replace(temp[0],"")
                            updated_ans = updated_ans.replace(p,"")

        if start!=-1:
            if p in updated_ans:
                tags.append(str(i+1))
                updated_ans = updated_ans.replace(p,"")

            if updated_ans.strip() in p:
                tags.append(str(i+1))
                updated_ans = ""


    return tags




def searchPage(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        return render(request,"search.html")


def autocomplete(request):
    print("In autocomplete ")
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "GET":
        query = request.GET['query']
        index_name = request.GET['index']
        res = es.search(index=indices,body={"query":{"match":{"question":query}}},search_type="dfs_query_then_fetch")
        res = res['hits']['hits']
        print("elasticsearch",res)
        questions = [r["_source"]['question'] for r in res ]
        ids = [r["_source"]['question_id'] for r in res ]
        answer = [r["_source"]['answer'] for r in res ]
        highlight = [r["_source"]['answer_paras'] for r in res ]
        highlight_ctx = [r["_source"]['ctx_paras'] for r in res ]
        res = []
        for ques,id,ans,h1,h2 in zip(questions,ids,answer,highlight,highlight_ctx):
        	res.append({
        		"question":ques,
        		"id":id,
        		"answer" : ans.replace('"',""),
                "highlight":h1,
                "highlight_ctx":h2
        		})
        data = json.dumps({"res":res})
        print("data",data)
        return HttpResponse(data, content_type='application/json')

def questionPagination(request):
    global paginator
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "GET":
        page_no = request.GET['page_no']
        if int(page_no) == 0:
            #criterion1 = Q(question__contains="")
            #criterion2 = Q(question__contains="")
            question_list = Question.objects.filter(votes__gte=0).filter(valid_question=1).exclude((Q(ctx_paras="") & Q(answer_paras=""))).order_by('-votes')
            paginator = Paginator(question_list, 6)
            print("paginator.num_pages",paginator.num_pages)
            return HttpResponse(json.dumps({"count":paginator.num_pages}),content_type='application/json')
        page_contents = paginator.page(int(page_no))
        res = []
        for record in page_contents:
            res.append({
                "question_id":record.question_id,
                "question":record.question,
                "answer":record.answer,
                "votes":record.votes if record.votes else 0,
                "highlight":record.answer_paras,
                "highlight_ctx":record.ctx_paras,
                "valid_question":record.valid_question

            })
    data = json.dumps({"res":res})
    print("data",data)
    return HttpResponse(data, content_type='application/json')


def getContextMC(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "POST":
        context_id = request.POST['context_id']
        answer = request.POST['answer']
        print("answer",answer)
        context_obj = Context.objects.get(context_id = context_id)
        file_id,page_id = context_id.split("__")
        highlight = get_answer_para_tags(answer, context_obj.page_html)
        res={
            "docspace_name":context_obj.namespace,
            "filespace_name":context_obj.file_name,
            "passage":context_obj.page_html,
            "page_id":int(page_id),
            "highlight":highlight,
            "filespace_id":context_obj.filespace_id,
            "namespace_id":context_obj.namespace_id,
        }
    #print(res)
    return HttpResponse(json.dumps(res) , content_type='application/json')





def getContext(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "GET":
        question_id = request.GET['question_id']
        file_id,page_id,qno = question_id.split("__")
        context_id = file_id + "__" + page_id
        context_obj = Context.objects.get(context_id = context_id)
        #print("context_obj.filespace_id",context_obj.filespace_id)
        #filespace_obj = Filespace.objects.get(filespace_id= context_obj.filespace_id)
        #docspace_obj = Namespace.objects.get(namespace_id= filespace_obj.namespace_id)
        res={
            "docspace_name":context_obj.namespace,
            "filespace_name":context_obj.file_name,
            "passage":context_obj.page_html,
            "filespace_id":context_obj.filespace_id,
            "namespace_id":context_obj.namespace_id,
            "page_id":int(page_id)
        }
        return HttpResponse(json.dumps(res) , content_type='application/json')


def vote(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "GET":
        question_id = request.GET['question_id']
        vote = int(request.GET['vote'])
        question_obj = Question.objects.get(question_id= question_id)
        curr_votes = question_obj.votes
        print("curr_votes",curr_votes)
        if curr_votes is None:
            if vote<0:
        	       question_obj.votes = -1
            else:
        	       question_obj.votes = 1
            question_obj.save()
            return HttpResponse(json.dumps({"status":"success","votes":question_obj.votes}),content_type='application/json')
        else:
            question_obj.votes = curr_votes + vote
            question_obj.save()
            print("----------------question_obj.votes",question_obj.votes)
            return HttpResponse(json.dumps({"status":"success","votes":question_obj.votes}),content_type='application/json')
    return HttpResponse(json.dumps({"status":"failure","votes":question_obj.votes}),content_type='application/json')
        #file_id,page_id,chunk_id,question_id = question_id.split("__")

def updateAns(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "POST":
        question_id = request.POST['question_id']
        updated_ans = request.POST['updated_ans']
        print("updated ans",updated_ans)
        question_obj = Question.objects.get(question_id= question_id)

        file_id,page_id,qno = question_id.split("__")
        context_id = file_id + "__" + page_id
        context_obj = Context.objects.get(context_id = context_id)

        tags = get_answer_para_tags_updated_ans(updated_ans,context_obj.page_html)
        print("tags",tags)

        #question_obj.answer_paras = ",".join([str(i) for i in tags])
        #question_obj.answer = updated_ans
        #question_obj.save()
        return HttpResponse(",".join(tags))
    return HttpResponse("failure")


def updateQuestion(request):
    if request.user.is_anonymous:
        return redirect("/")
    if request.method == "GET":
        question_id = request.GET['question_id']
        updated_qs = request.GET['updated_qs']
        question_obj = Question.objects.get(question_id= question_id)
        question_obj.question = updated_qs
        question_obj.save()
        return HttpResponse("success")
    return HttpResponse("failure")



def getSimilarQuestions(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        question = request.GET['question']
        query_vector = embed_text([question])[0]
        script_query = {
            "script_score": {
                "query": {"match_all": {}},
                "script": {
                    "source": "cosineSimilarity(params.query_vector, doc['question_vector']) + 1.0",
                    "params": {"query_vector": query_vector}
                }
            }
        }
        res =  es.search(
        index=indices,
        body={
            "size": 6,
            "query": script_query,
            "_source": {"includes": ["question","question_id","answer","answer_paras","ctx_paras"]}
            }
        )
        res = res['hits']['hits']
        print("elasticsearch",res)
        questions = [r["_source"]['question'] for r in res ]
        ids = [r["_source"]['question_id'] for r in res ]
        answer = [r["_source"]['answer'] for r in res ]
        highlight = [r["_source"]['answer_paras'] for r in res ]
        highlight_ctx = [r["_source"]['ctx_paras'] for r in res ]
        res = []
        for ques,id,ans,h1,h2 in zip(questions,ids,answer,highlight,highlight_ctx):
            res.append({
                "question":ques,
                "question_id":id,
                "answer" : ans,
                "highlight":h1,
                "highlight_ctx":h2,
                "votes":0
                })
        data = json.dumps({"res":res})
        print("data",data)
        return HttpResponse(data, content_type='application/json')



def getSimilarPassages(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        question = request.GET['question']
        """
        question_embeddings = model_pass.signatures['question_encoder'](
            tf.constant([question]))
        query_vector = question_embeddings['outputs'][0].numpy().tolist()
        script_query = {
            "script_score": {
                "query": {"match_all": {}},
                "script": {
                    "source": "cosineSimilarity(params.query_vector, doc['passage_vector']) + 1.0",
                    "params": {"query_vector": query_vector}
                }
            }
        }
        res = es.search(
        index="retieval_qa",
        body={
            "size": 5,
            "query": script_query,
            "_source": {"includes": ["file_name","passage_id","passage","answer","answer_paras","ctx_paras"]}
            }
        )
        res = res['hits']['hits']
        questions = [r["_source"]['file_name'] for r in res ]
        ids = [r["_source"]['passage_id'] for r in res ]
        answer = [r["_source"]['answer'] for r in res ]
        highlight = [r["_source"]['answer_paras'] for r in res ]
        highlight_ctx = [r["_source"]['ctx_paras'] for r in res ]
        res = []
        for ques,id,ans,h1,h2 in zip(questions,ids,answer,highlight,highlight_ctx):
            res.append({
                "question":ques,
                "question_id":id,
                "answer" : ans,
                "highlight":h1,
                "highlight_ctx":h2
                })
        data = json.dumps({"res":res})
        print("data",data)
        return HttpResponse(data, content_type='application/json')
        """
        res = es.search(index=indices_chunk,body=
                                {"size":20,"query":{"match":{"passage":question}}},
                                    search_type="dfs_query_then_fetch")
        res = res['hits']['hits']
        print(res)
        questions = [r["_source"]['file_name'] for r in res ]
        ids = [r["_source"]['passage_id'] for r in res ]
        answer = [r["_source"]['passage'] for r in res ]
        highlight = [" " for r in res ]
        highlight_ctx = [r["_source"]['ctx_paras'] for r in res ]
        res = []
        for ques,id,ans,h1,h2 in zip(questions,ids,answer,highlight,highlight_ctx):
                mc_ans = model_mc({
                'question': question,
                'context': ans
                })
                res.append({
                    "question":ques,
                    "question_id":id,
                    "answer" : ans,
                    "highlight":h1,
                    "highlight_ctx":h2,
                    "score":mc_ans['score']
                    })
        res = sorted(res,key=lambda x:x['score'],reverse=True)
        data = json.dumps({"res":res[:8]})
        print("data",data)
        return HttpResponse(data, content_type='application/json')



