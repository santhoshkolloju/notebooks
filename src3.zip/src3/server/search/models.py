from django.db import models
from filespace.models import Filespace
from namespace.models import Namespace

# Create your models here.


class Context(models.Model):
	namespace_id = models.CharField(max_length=30)
	filespace_id = models.CharField(max_length=30)
	file_name = models.CharField(max_length=30)
	namespace = models.CharField(max_length=30)
	page_id = models.IntegerField(default=1)
	page_html = models.TextField(blank=True)
	context_id = models.TextField(primary_key=True)
	def __str__(self):
		return str(self.filespace_id) + "__"+str(self.page_id)


class Passage(models.Model):
	namespace_id = models.CharField(max_length=30)
	filespace_id = models.CharField(max_length=30)
	file_name = models.CharField(max_length=30)
	namespace = models.CharField(max_length=30)
	page_id = models.IntegerField(default=1)
	passage = models.TextField(blank=True)
	passage_id = models.TextField(primary_key=True)
	def __str__(self):
		return str(passage_id)



class Question(models.Model):
	context_id = models.CharField(max_length=30)
	namespace_id = models.CharField(max_length=30)
	filespace_id = models.CharField(max_length=30)
	file_name = models.CharField(max_length=30)
	namespace = models.CharField(max_length=30)
	question = models.TextField(blank=True)
	answer = models.TextField(blank=True)
	answer_paras = models.TextField(blank=True)
	confidence = models.FloatField(default=1.0)
	question_id = models.TextField(blank=True,primary_key=True)
	votes = models.IntegerField(default=0)
	ctx_paras = models.TextField(blank=True)
	valid_question = models.IntegerField(default=1)

	class Meta:
		ordering = ('votes',)

	def __str__(self):
		return self.question


class Edits(models.Model):
    question_id = models.TextField(blank=True)
    question = models.TextField(blank=True)
    user_id = models.IntegerField(default=1)
    updated_time = models.TimeField(auto_now_add=True)
    answer = models.TextField(blank=True)
    def __str__(self):
    	return self.question
