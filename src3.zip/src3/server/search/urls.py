from django.contrib import admin
from django.urls import path
from .views import (searchPage,autocomplete,questionPagination,getContext,vote,updateAns,
updateQuestion,getContextMC,getSimilarQuestions,getSimilarPassages)

urlpatterns = [
    path('', searchPage),
    path('/autocomplete',autocomplete),
    path("/pagination",questionPagination),
    path("/context",getContext),
    path("/vote",vote),
    path("/updateAns",updateAns),
    path("/updateQuestion",updateQuestion),
    path("/getContextMC",getContextMC),
    path("/similarques",getSimilarQuestions),
    path("/similarpassages",getSimilarPassages)
]
