from django.shortcuts import render
from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from django.contrib.auth.models import AnonymousUser


# Create your views here.

def landingPage(request):
	return render(request , "landing.html", {})



def handleLogin(request):
	print("Login method")
	if request.method == "POST":
		uname = request.POST['username']
		password = request.POST['password']
		#path = request.POST['path']
		print(uname, password)

		user = authenticate(username = uname , password = password)
		print(user)
		if user is not None:
			login(request , user)
			return HttpResponse("success")
		else:
			return HttpResponse("failed")


def handleLogout(request):
	print("In logout now")
	if request.method == "POST":
		for sesskey in request.session.keys():
			del request.session[sesskey]
		logout(request)
		#request.user = None
		return redirect("/")
	return redirect("/")
