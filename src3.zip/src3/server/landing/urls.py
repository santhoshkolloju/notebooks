from django.contrib import admin
from django.urls import path
from .views import landingPage,handleLogin,handleLogout

urlpatterns = [
    path('', landingPage),
    path('login',handleLogin),
    path('logout',handleLogout)
]
