from django.contrib import admin
from django.urls import path
from .views import feedbackPage,getFileList,getPdfContent,createQuestion,getQuestions


urlpatterns = [
    path('', feedbackPage),
    path("/getFileList",getFileList),
    path("/getPdfContent",getPdfContent),
    path("/createQuestion",createQuestion),
    path("/getQuestions",getQuestions)
]
