from django.db import models

# Create your models here.


class ManualQuestions(models.Model):
    filespace_id = models.CharField(max_length=30)
    question = models.CharField(max_length=30)
    context = models.TextField(blank=True)
    page_no = models.IntegerField(default=0)
    def __str__(self):
        return self.question
