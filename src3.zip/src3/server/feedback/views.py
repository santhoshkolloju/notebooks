from django.shortcuts import render,redirect,HttpResponse
import fitz
from namespace.models import Namespace
from filespace.models import Filespace
from .models import ManualQuestions
from djongo.storage import GridFSStorage
from django.conf import settings
import json
grid_fs_storage = GridFSStorage(collection='myfiles', base_url=''.join([settings.BASE_DIR, 'myfiles/']))

# Create your views here.

def feedbackPage(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        namespaces = Namespace.objects.all()
        return render(request,"feedback.html",{"namespaces":namespaces})

def getPdfContent(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        filespace_id = request.GET['filespace_id']
        fobj = Filespace.objects.get(filespace_id=filespace_id)
        filename = fobj.file_name
        file = grid_fs_storage._open("sample_docs/"+filename)
        f = open('tempfigfile.pdf', 'wb')
        f.write(file.read())
        f.close()
        doc = fitz.open('tempfigfile.pdf')
        toc = doc.getToC()
        totalpages = doc.pageCount
        res =[]
        for page_no in range(totalpages):
            page = doc.loadPage(page_no)
            html = page.getText("html")
            res.append({
                "html":html,
                "filespace_id":filespace_id
            })
        data = json.dumps({"res":res})
        return HttpResponse(data, content_type='application/json')







def getFileList(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        namespace_id = request.GET['namespace_id']
        filespaces = Filespace.objects.filter(namespace_id = namespace_id)
        res = []
        for record in filespaces:
            res.append({
                "file_name":record.file_name,
                "filespace_id":record.filespace_id
            })
        data = json.dumps({"res":res})
        print("data",data)
        return HttpResponse(data, content_type='application/json')

def createQuestion(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        filespace_id = request.POST['filespace_id']
        page_no = request.POST['page_no']
        question = request.POST['question']
        context = request.POST['context']
        n1 = ManualQuestions(filespace_id = filespace_id,
                        question = question, context=context, page_no=page_no)
        n1.save()
        return HttpResponse("success")

def getQuestions(request):
    if request.user.is_anonymous:
        return redirect("/")
    else:
        filespace_id = request.GET['filespace_id']
        page_no = request.GET['page_no']

        questions = ManualQuestions.objects.filter(filespace_id = filespace_id,page_no=page_no)
        res = []
        for record in questions:
            res.append({
                "question":record.question,
                "context":record.context
            })
        data = json.dumps({"res":res})
        print("data",data)
        return HttpResponse(data, content_type='application/json')
