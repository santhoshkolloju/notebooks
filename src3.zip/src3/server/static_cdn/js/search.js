
var mc_results = []
//functions to ge the selcted range of text
function selectElementText(el) {
    var range = document.createRange() // create new range object
    range.selectNodeContents(el) // set range to encompass desired element text
    var selection = window.getSelection() // get Selection object from currently user selected text
    selection.removeAllRanges() // unselect any user selected text (if any)
    selection.addRange(range) // add range to Selection object to select it
}

function getSelectedText() {
    if (window.getSelection) {
        return window.getSelection().toString();
    } else if (document.selection) {
        return document.selection.createRange().text;
    }
    return '';
}

//functions to ge the selcted range of text

$(document).ready(function(){

  $(".search").children('div').css("background-color", "#ea7db2")



  $(".similar-tab").on("click",function(e){

    $(this).removeClass('closed-tab')
    $(this).addClass('open-tab')
    $(this).css("border-left","none")
    $(".search-tab").removeClass('open-tab')
    $(".search-tab").addClass('closed-tab')
    $(".search-tab").css('border-left','solid 1px rgb(185, 101, 181)')
    //$(".on-search").css("display","none")
    $(".mc_results_left").css("display","none")
    $(".mc_results_similar_left").css("display","block")
    $.ajax({
              type: 'GET',
              url: "/search/similarques?question="+$('#auto-complete').val(),
              beforeSend: function() {
                  //$('.loader').css('display', 'block')
                  //alert("here")

              },
              success: function(data) {

                $(".question-list-similar").empty()
                for(i=0;i<data['res'].length;i++){
                  $(".question-list-similar").append(`<div style="position:relative"><li question_id = "`+data['res'][i]['question_id']+`"
                    answer = "`+data['res'][i]['answer']+`" highlight="`+data['res'][i]['highlight']+`"`+
                    ` highlight_ctx="`+data['res'][i]['highlight_ctx']+`"
                    class="list-group-item d-flex justify-content-between align-items-center"><p>
                    `+data['res'][i]['question']+`</p>
                    
                  </li>
                  
                  `)




                }

                $(".question-list-similar li").first().click()
                


              }

          });//ajax for question click



    
    

  })//tab click

  $(".search-tab").on("click",function(e){

    $(this).removeClass('closed-tab')
    $(this).addClass('open-tab')
    //$(this).css("border-left","none")
    $(".similar-tab").removeClass('open-tab')
    $(".similar-tab").addClass('closed-tab')
    $(".mc_results_similar_left").css("display","none")
    $(".mc_results_left").css("display","block")
    //$(".search-tab").css('border-left','solid 1px rgb(185, 101, 181)')

  })//tab click



  $.ajax({
        type: 'GET',
        url: "/search/pagination?page_no=0",
        beforeSend: function() {
            $('.loader').css('display', 'block')
        },
        success: function(data) {

            count  = data["count"]
            if(count < 5){
                for (i = 1 ; i <= count; i++){

                   $(".pagination").append
                   (`<li class="page-item"><a class="page-link" href="#">` + i + `</a></li>`)

                }

            }
            else{

              for (i = 1 ; i <= 5; i++){

                 $(".pagination").append
                 (`<li class="page-item"><a class="page-link" href="#">` + i + `</a></li>`)

              }
              $(".pagination").append
              (`<li class="page-item" name="group_1" ><a class="page-link next-ques" href="#"
              prev ="0" next="2" current="1" count="`+count+`">` + "next" + `</a></li>`)



            }
            $(".pagination li").first().find("a").click()
            $(".pagination li").first().addClass("active")

        }

    });//ajax for pagination


      $("body").on("click",'.next-ques',function(e){
        next = $(this).attr("next")
        prev = $(this).attr("prev")
        count= $(this).attr("count")
        current = $(this).attr("current")
        $(".pagination").empty()
        $(".pagination").append
        (`<li class="page-item" name="group_1" ><a class="page-link prev-ques" href="#"
        prev ="`+current+`" next="`+(parseInt(current)+2)+`" current="`+(parseInt(current)+1)+`"
        count="`+count+`">` + "Prev" + `</a></li>`)
        parsed_count = parseInt(current)*5
        remaining_count = parseInt(count) - parsed_count
        if(remaining_count < 5){
          for (i = parsed_count+1 ; i <= count; i++){

             $(".pagination").append
             (`<li class="page-item"><a class="page-link" href="#">` + i + `</a></li>`)

          }

        }
        else{
          current  = parseInt(next);
          (`<li class="page-item" name="group_1" ><a class="page-link prev-ques" href="#"
          prev ="`+(current - 1)+`" next="`+(current+1)+`" current="`+current+`" count="`+count+`">` +
          "Prev" + `</a></li>`)
          for (i = parsed_count+1 ; i <= parsed_count + 5; i++){

             $(".pagination").append
             (`<li class="page-item"><a class="page-link" href="#">` + i + `</a></li>`)

          }

          $(".pagination").append
          (`<li class="page-item" name="group_1" ><a class="page-link next-ques" href="#"
          prev ="`+(current - 1)+`" next="`+(current+1)+`" current="`+current+`" count="`+count+`">` +
          "next" + `</a></li>`)

        }
        //alert("here")
        $(".pagination li").first().next().find("a").click();
        //$(".pagination li").first().next().addClass("active");

      })//next click

      $("body").on("click",'.prev-ques',function(e){
        prev = $(this).attr("prev")
        count = $(this).attr("count")
        current  = parseInt(prev)
        parsed_count = parseInt(current)*5;
        $(".pagination").empty();
        if ((current - 1) != 0){
         $(".pagination").append(`<li class="page-item" name="group_1" ><a class="page-link prev-ques" href="#"
        prev ="`+(current - 1)+`" next="`+(current+1)+`" current="`+current+`" count="`+count+`">` +
        "Prev" + `</a></li>`)
      }
        for (i = (parsed_count-5+1) ; i <= parsed_count ; i++){

           $(".pagination").append
           (`<li class="page-item"><a class="page-link" href="#">` + i + `</a></li>`)

        }

        $(".pagination").append
        (`<li class="page-item" name="group_1" ><a class="page-link next-ques" href="#"
        prev ="`+(current - 1)+`" next="`+(current+1)+`" current="`+current+`" count="`+count+`">` +
        "next" + `</a></li>`)
        if ((current - 1) != 0){
        $(".pagination li:nth-child(2)").find("a").click()
        $(".pagination li:nth-child(2)").addClass("active")
      }
      else{
          $(".pagination li:nth-child(1)").find("a").click()
          $(".pagination li:nth-child(1)").addClass("active")
      }



      })//prev click



      $("body").on("click",".page-link",function(e){
        //alert($(this).text()!="next")
        var page_no = $(this).text()
        //alert(page_no.localeCompare("next"))
        if (page_no.localeCompare("next")!=0 && page_no.localeCompare("Prev")!=0){
           $(".page-item").removeClass("active")
           $(this).parent().addClass("active")

        $.ajax({
              type: 'GET',
              url: "/search/pagination?page_no="+$(this).text(),
              beforeSend: function() {
                  $('.loader').css('display', 'block')
              },
              success: function(data) {
                console.log(data)
                $(".question-list-faq").empty()
                for(i=0;i<data['res'].length;i++){
                  $(".question-list-faq").append(`<div style="position:relative"><li question_id = "`+data['res'][i]['question_id']+`"
                    answer = "`+data['res'][i]['answer']+`" highlight="`+data['res'][i]['highlight']+`"`+
                    ` highlight_ctx="`+data['res'][i]['highlight_ctx']+`"
                    class="list-group-item d-flex justify-content-between align-items-center"><p>
                    `+data['res'][i]['question']+`</p>
                    <span class="badge badge-primary badge-pill votes" style="position: absolute;left: 0px;top: 0px;
                    background-color:black;" question_id = "`+data['res'][i]['question_id']+`">`+data['res'][i]['votes']+`</span>

                  

                  </li>
                  <span style="position: absolute;right: 7px;top: 0px; z-index:100;"
                  class="edit" question_id = "`+data['res'][i]['question_id']+`" >
                  <i class="fas fa-edit"></i></span>
                  `)




                }

                $(".questions-list li").first().click()


              }

          });//ajax for pagination click
        }



      })//on clicking the pagination link


      $("body").on("click",".questions-list li",function(e){
        //alert("here")
        var answer = $(this).attr("answer")
        var highlight_ctx = $(this).attr("highlight_ctx").split(",")
        console.log("highlight_ctx",highlight_ctx)
        var highlight =  $(this).attr("highlight").split(",")
        var question_id = $(this).attr("question_id")
        console.log(answer)
        $(".questions-list li").removeClass('question-background')
        $('.mc-results li').removeClass('question-background')
        $(this).addClass('question-background')
        var question_id = $(this).attr("question_id")
        $.ajax({
              type: 'GET',
              url: "/search/context?question_id="+$(this).attr("question_id"),
              beforeSend: function() {
                  //$('.loader').css('display', 'block')
                  //alert("here")

              },
              success: function(data) {
                console.log(data)
                //idx = data['passage'].indexOf(answer)
                //pre_ans = data['passage'].substring(0, idx)
                //post_ans = data['passage'].substring(idx + answer.length)

                //context_html = pre_ans + `<span class="label label-primary" style="background-color:gold;">` + answer + `</span>` + post_ans

                console.log(highlight)
                $(".context").empty()
                $(".context").append(data['passage'])
                //$("#page0 p").css("left","20px");
                //$("#page0").css("width","100%");
                //$("#page0").css("height","100%");

                //$.each(highlight, function(k, v) {
                //    console.log("child",v)
                //    $("#page0 p:nth-child("+v+")").css("background","goldenrod")
                //});
                $(".thumbsup").attr("question_id",question_id)
                $(".thumbsdown").attr("question_id",question_id)
                var cs = ""
                if ($(".landing-results").css("display") == "none"){
                  var cs = ".context_mc "
                }
                else{
                  var cs = ".context_lan "
                }
                console.log(cs)
                firstchildtop = $(cs+"#page0 p:nth-child(1)").css("top").replace("px","");

                 $(cs+"#page0 p").each(function(k,v){
                   //console.log(firstchildtop)
                   if (highlight_ctx.includes((k+1).toString())){
                     console.log("backgroun p",k)
                     $(this).css("background","lightgreen")
                   }
                   if (highlight.includes((k+1).toString())){
                     console.log("backgroun p",k)
                     $(this).css("background","goldenrod")
                   }



                   //toppx = $(this).css('top').replace("px","")
                   //console.log(toppx)
                   //newtop = parseInt(toppx) - parseInt(firstchildtop)
                   //console.log(newtop)
                   //$(this).css("top",newtop.toString()+"px")


                 })//change the top position of page html

                 $($(cs+"#page0").children().get().reverse()).each(function(k,v){
                    if(v.hasAttribute("src")){
                      $(this).css("display","none")
                    }
                    else{
                        return false; // breaks

                    }


                 })


                $(".context").attr("question_id",question_id)
                $('.doc-space').text(data['docspace_name'])
                $(".doc-name").text(data['filespace_name'].slice(0,50))
                //console.log("/filespace?namespace_id="+data['namespace_id']+"&docspace_name="+data['docspace_name'])
                $(".doc-space").attr("href","/filespace?namespace_id="+data['namespace_id']+"&docspace_name="+data['docspace_name'])
                $(".doc-name").attr("href","/filespace/download?namespace_id="
                  +data['namespace_id']+"&filespace_id="+data['filespace_id']+"#page="+data['page_id'])


              }

          });//ajax for question click




      })//question click event


      $("body").on("click",".thumbsup",function(e){
        current = $(this)
        question_id = $(this).attr("question_id")

        $.ajax({
              type: 'GET',
              url: "/search/vote?vote=1&question_id="+$(this).attr("question_id"),
              beforeSend: function() {
                  //$('.loader').css('display', 'block')
                  //alert("here")

              },
              success: function(data) {
                if (data['status'] == "success") {


                  $("#snackbar").html("Successfully upvoted the Question")
                  $("#snackbar").addClass("show");
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);
                  $("span[class$='votes'][question_id$='"+question_id+"']").css("display","block")
                  $("span[class$='votes'][question_id$='"+question_id+"']").text(data['votes'])

                } else if (data['status']  == "failure") {
                  $("#snackbar").addClass("show");
                  $("#snackbar").html("Upvoting the Question Failed")
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);

                  $("span[class$='votes'][question_id$='"+question_id+"']").text(data['votes'])

                }


              }

          });//ajax for question click





      });// thumps up click
      $("body").on("click",".thumbsdown",function(e){
          current = $(this)
          question_id = $(this).attr("question_id")
        $.ajax({
              type: 'GET',
              url: "/search/vote?vote=-1&question_id="+$(this).attr("question_id"),
              beforeSend: function() {
                  //$('.loader').css('display', 'block')
                  //alert("here")

              },
              success: function(data) {
                if (data['status'] == "success") {

                  $("#snackbar").html("Successfully downvoted the Question")
                  $("#snackbar").addClass("show");
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);
                  $("span[class$='votes'][question_id$='"+question_id+"']").text(data['votes'])

                } else if (data['status']  == "failure") {
                  $("#snackbar").addClass("show");
                  $("#snackbar").html("Downvoting the Question Failed")
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);
                  $("span[class$='votes'][question_id$='"+question_id+"']").css("display","block")
                  $("span[class$='votes'][question_id$='"+question_id+"']").text(data['votes'])
                }


              }

          });//ajax for question click





      });// thumps up click


      $("body").on("click",".edit",function(){

        $("#QuestionModal").modal()
        $("#edit_question").val($(this).parent().find("p").text().trim())
        $("#update_ques").attr("question_id",$(this).attr("question_id"))

      })//on clicking the edit

        $("body").on("click","#update_ques",function(){
          var qs = $("#edit_question").val()
          var question_id= $(this).attr("question_id")
          $.ajax({
                type: 'GET',
                url: "/search/updateQuestion?&question_id="+$(this).attr("question_id")+"&updated_qs="+qs,
                beforeSend: function() {
                    //$('.loader').css('display', 'block')
                    //alert("here")

                },
                success: function(data) {
                  if (data == "success") {
                    //console.log($(".questions-list li").find(`[question_id=`+question_id+`]`))
                    //console.log(ans)

                    $(".questions-list").find(`[question_id=`+question_id+`]`).find("p").text(qs)
                    $("#snackbar").html("Successfully updated the Question")
                    $("#snackbar").addClass("show");
                    setTimeout(function() {
                      $("#snackbar").removeClass("show");
                    }, 3000);



                  } else if (data  == "failure") {
                    $("#snackbar").addClass("show");
                    $("#snackbar").html("Updating the Question Failed")
                    setTimeout(function() {
                      $("#snackbar").removeClass("show");
                    }, 3000);

                  }


                }

            });//ajax for question update


        })//submit question update



      
      $("body").on("mouseup", ".context", function() {
        var question_id = $(this).attr("question_id")
      console.log("selected text",window.getSelection())
        setTimeout(function() {

            text = getSelectedText()
            if (text != "") {
                var open_tab = $('div.panel-collapse.show')
                //alert(open_tab.attr("id"));
                //alert(text);
                $("#AnswerModal").modal()
                $("#updated_ans").val(text)
                $("#submit-update-ans").attr("question_id",question_id)

            }

        }, 1000)
      }); //answer updating on selecting the textt
      








      $("body").on("click","#submit-update-ans",function(e){

        var ans  = $("#updated_ans").val()
        var question_id = $(this).attr("question_id")
        
        $.ajax({
              type: 'POST',
              url: "/search/updateAns",
              beforeSend: function(xhr,settings) {
                  //$('.loader').css('display', 'block')
                  //alert("here")
                  function getCookie(name) {
             var cookieValue = null;
             if (document.cookie && document.cookie != '') {
                 var cookies = document.cookie.split(';');
                 for (var i = 0; i < cookies.length; i++) {
                     var cookie = jQuery.trim(cookies[i]);
                     // Does this cookie string begin with the name we want?
                     if (cookie.substring(0, name.length + 1) == (name + '=')) {
                         cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                         break;
                     }
                 }
             }
             return cookieValue;
         }
         if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
             // Only send the token to relative URLs i.e. locally.
             xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
         }

              },
              data:{
                "question_id":$(this).attr("question_id"),
                "updated_ans":ans
              },
              success: function(data) {


                    if (data  == "failure") {
                            $("#snackbar").addClass("show");
                            $("#snackbar").html("Updating the Answer Failed")
                            setTimeout(function() {
                              $("#snackbar").removeClass("show");
                            }, 3000);

                          }

                    else{
                          console.log($(".questions-list li").find(`[question_id=`+question_id+`]`))
                          console.log(ans)
                          $(".questions-list").find(`[question_id=`+question_id+`]`).attr("answer",ans)
                          $(".questions-list").find(`[question_id=`+question_id+`]`).attr("highlight",data)
                          $(".questions-list li").find(`[question_id=`+question_id+`]`).click()
                          $("#snackbar").html("Successfully updated the Answer")
                          $("#snackbar").addClass("show");
                          setTimeout(function() {
                            $("#snackbar").removeClass("show");
                          }, 3000);



                                    } 
                          


                                  }//success





              

          });//ajax for question click




        




      });//update the anser in mongodb



      











});//ready
//autocomplete elastic search request
var options = {
  url: function(phrase) {
      var data = phrase !== '' ? "/search/autocomplete?query=" + phrase + "&index=test_index" :
          'http://api.duckduckgo.com/?q=empty&format=json';
      console.log("data",data)

      return data
  },
  getValue: function(element) {
      console.log(element)
      return element.question;
  },
  ajaxSettings: {
      type: 'GET',
      dataType: 'json',
      cors: true,
      contentType: 'application/json',
      secure: true,
      headers: {
          'Access-Control-Allow-Origin': '*',
      }
  },//ajax settings closing here

  listLocation: 'res',
  requestDelay: 300,
  list: {

      onLoadEvent: function() {

          //$(".easy-autocomplete").css("width", "100%")


      },
      onClickEvent: function() {
        var question = $("#auto-complete").val();
        var question_id = $("#auto-complete").getSelectedItemData().id
       var answer = $("#auto-complete").getSelectedItemData()
       console.log("answer",answer)
       var highlight = $("#auto-complete").getSelectedItemData().highlight
       var highlight_ctx= $("#auto-complete").getSelectedItemData().highlight_ctx
       console.log(highlight_ctx)
        $(".landing-results").css("display","none")
        $(".on-search").css("display","block")
        $(".questions-list-search").html(`<li question_id = "`+question_id+`"
          answer = "`+answer+`"`+`highlight="`+highlight+`"`+
                    `highlight_ctx="`+highlight_ctx+`"
          class="list-group-item d-flex justify-content-between align-items-center">
          `+question+`
          <span class="badge badge-primary badge-pill votes" style="display:none;position: absolute;left: 0px;top: 0px;
          background-color:black;">`+"12"+`</span>

        <span style="position: absolute;right: 7px;top: 0px;"
        class="edit" question_id = "`+question_id+`" >
        <i class="fas fa-edit"></i></span>




        </li>`)
        $(".questions-list-search li").click()
        $("#snackbar").html("Fetching other documents which might answer the query")
        $("#snackbar").addClass("show");
        setTimeout(function() {
          $("#snackbar").removeClass("show");
        }, 3000);


        $.ajax({
              type: 'GET',
              url: "/search/similarpassages?question="+question,
              beforeSend: function() {
                 $(".mc-results").empty()
                  $('.loader').css('display', 'block')
              },
              headers: {
              'Access-Control-Allow-Origin': '*'
            },
              success: function(data) {
                console.log("results from es",data['res'])
                if (data['res']=="no results found"){
                  $("#snackbar").html("Couldn't find any extra results ")
                  $("#snackbar").addClass("show");
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);
                  $('.loader').css('display', 'none')

                }
                else{
                $('.loader').css('display', 'none')

                $(".mc-results").empty()
                    for(i=0;i<data['res'].length;i++){
                      $(".mc-results").append(`
                        <div style="position:relative"><li question_id = "`+data['res'][i]['question_id']+`"
                        answer = "`+data['res'][i]['answer']+`" highlight="`+data['res'][i]['highlight']+`"`+
                        ` highlight_ctx="`+data['res'][i]['highlight_ctx']+`"
                        class="list-group-item d-flex justify-content-between align-items-center"><p>
                        `+data['res'][i]['question'].slice(0,50)+`</p>
                        
                      </li>
                      
                      `)




                    }

                    
                  }//else


              }

          });//ajax for question click










      }

    }//list closing here

  }//options closing here
  $('#auto-complete').easyAutocomplete(options);
  //$(".easy-autocomplete").css("width","60%")
  //$(".easy-autocomplete").css("height","100%")
  //$(".easy-autocomplete-container").css("width","60%")


  $('#auto-complete').keydown(function(event) {
      //$(".loading-fa").css("display", "inline-block")
      //$(".filtericon-fa").css("display", "none")
      var keyCode = (event.keyCode ? event.keyCode : event.which);
      if (keyCode == 13) {
          //call the elastic search
          //alert("autocomplete not selected")
          $(".landing-results").css("display","none")
          $(".on-search").css("display","block")
          $(".mc-res-container").css("height","90%")
          $(".context").empty()
          $(".ac-single-ques").css("display","none")
          $(".mc-res-helptxt").text("Results from machine comprehension model")
          $("#snackbar").html("Fetching Results Please wait..")
          $("#snackbar").addClass("show");
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);
          var question = $('#auto-complete').val()

          $.ajax({
                type: 'GET',
                url: "/search/similarpassages?question="+question,
                beforeSend: function() {
                   $(".mc-results").empty()
                    $('.loader').css('display', 'block')
                },
                headers: {
                'Access-Control-Allow-Origin': '*'
              },
                success: function(data) {
                  console.log("reslts",data['res'])
                  if (data['res']=="no results found"){
                    $("#snackbar").html("Couldn't find any extra results ")
                    $("#snackbar").addClass("show");
                    setTimeout(function() {
                      $("#snackbar").removeClass("show");
                    }, 3000);
                    $('.loader').css('display', 'none')

                  }
                  else{
                  $('.loader').css('display', 'none')
                    $(".mc-results").empty()
                    for(i=0;i<data['res'].length;i++){
                      $(".mc-results").append(`
                        <div style="position:relative"><li question_id = "`+data['res'][i]['question_id']+`"
                        answer = "`+data['res'][i]['answer']+`" highlight="`+data['res'][i]['highlight']+`"`+
                        ` highlight_ctx="`+data['res'][i]['highlight_ctx']+`"
                        class="list-group-item d-flex justify-content-between align-items-center"><p>
                        `+data['res'][i]['question'].slice(0,50)+`</p>
                        
                      </li>
                      
                      `)




                    }

                    //$(".mc-results li").first().click()
                  
                    }//else


                }

            });//ajax for question click

      }
  });
