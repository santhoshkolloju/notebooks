$(document).ready(function(){

	$(".login-in-display-btn").on("click",function(event){

		event.preventDefault()

		$(".login-form").css({
			"display":"block",
			transition : 'all 1s ease-in-out',WebkitTransition : 'all 1s ease-in-out'

		})
		$(".landing-side-image").css({
			"opacity":"0.25",
			transition : 'all 1s ease-in-out',WebkitTransition : 'all 1s ease-in-out'
		})


	}); //login form click event

	$(".login-form").submit(
		function(event){
			event.preventDefault();
			$.ajax({
				type:"POST",
				url:"/login",
				data:$(".login-form").serialize(),
				success: function (data) {
					if (data == "success" ){
						//console.log(data)
						//alert(data);
						$("#snackbar").html("Login " + data)
						$("#snackbar").addClass("show");
						setTimeout(function(){ $("#snackbar").removeClass("show"); }, 3000);
					  window.location.href = "/namespace"
				}
				else{
					window.location.href="/"
					$("#snackbar").html("some error occured login failed")
					$("#snackbar").addClass("show");
					setTimeout(function(){ $("#snackbar").removeClass("show"); }, 3000);

				}

				},//success
				error:function(){
					$("#snackbar").html("some error occured")
					$("#snackbar").addClass("show");
					setTimeout(function(){ $("#snackbar").removeClass("show"); }, 3000);

				}//error
			});//ajax ends here

		}//function
	);//submit


});
