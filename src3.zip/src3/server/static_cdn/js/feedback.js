 var pdffiledata = []
 function selectElementText(el) {
     var range = document.createRange() // create new range object
     range.selectNodeContents(el) // set range to encompass desired element text
     var selection = window.getSelection() // get Selection object from currently user selected text
     selection.removeAllRanges() // unselect any user selected text (if any)
     selection.addRange(range) // add range to Selection object to select it
 }

 function getSelectedText() {
     if (window.getSelection) {
         return window.getSelection().toString();
     } else if (document.selection) {
         return document.selection.createRange().text;
     }
     return '';
 }

 //functions to ge the selcted range of text
$(document).ready(function(){

  $(".dropdown-menu-doc  a").click(function(){
        var selText = $(this).text();
        var namespace_id = $(this).attr("id");
        console.log("namespace_id",namespace_id)

        $("#dropdown_doc").text(selText);
        $.ajax({
              type: 'GET',
              url: "/feedback/getFileList?namespace_id="+namespace_id,
              beforeSend: function() {
                  //$('.loader').css('display', 'block')
                  //alert("here")

              },
              success: function(data) {
                  $(".dropdown-menu-file").empty()
                  for(i=0;i<data['res'].length;i++){
                  $(".dropdown-menu-file").append(`
                    <a class="dropdown-item" href="#"
                    id="`+data['res'][i]['filespace_id']+`">`+data['res'][i]['file_name']+`</a>

                    `)
                  }


              }

          });//ajax for question click




     });//on selecting the dropdown


     $("body").on("click",".dropdown-menu-file  a",function(){
           var selText = $(this).text();
           var filespace_id = $(this).attr("id");
           console.log("filespace_id",filespace_id)

           $("#dropdown_file").text(selText);
           $.ajax({
                 type: 'GET',
                 url: "/feedback/getPdfContent?filespace_id="+filespace_id,
                 beforeSend: function() {
                     //$('.loader').css('display', 'block')
                     //alert("here")

                 },
                 success: function(data) {
                     console.log(data.length)
                     for (i = 0 ; i < data['res'].length; i++){

                        $(".pagination").append
                        (`<li class="page-item"><a class="page-link" href="#">` + (i+1) + `</a></li>`)
                        pdffiledata[i] = {
                          "html":data['res'][i]['html'],
                          "filespace_id" : data['res'][i]['filespace_id']
                        }

                     }
                     $(".pagination li").first().find("a").click()
                     $(".pagination li").first().addClass("active")


                 }


             });//ajax for question click




        });//on selecting the dropdown


        $("body").on("click",".page-link",function(e){
          var page_no = parseInt($(this).text())-1
          $(".context").empty()
          $(".context").append(pdffiledata[page_no]['html'])
          $(".context").attr("filespace_id",pdffiledata[page_no]['filespace_id'])
          $(".context").attr("page_no",$(this).text())
          firstchildtop = $("#page0 p:nth-child(1)").css("top").replace("px","");

           $("#page0 p").each(function(k,v){

             toppx = $(this).css('top').replace("px","")
             //console.log(toppx)
             newtop = parseInt(toppx) - parseInt(firstchildtop)
             //console.log(newtop)
             $(this).css("top",newtop.toString()+"px")


           })//change the top position of page html
           $(".page-item").removeClass("active")
           $(this).parent().addClass("active")

           $.ajax({
                 type: 'GET',
                 url: "/feedback/getQuestions?filespace_id="+pdffiledata[page_no]['filespace_id']+"&page_no="+$(this).text(),
                 beforeSend: function() {
                     //$('.loader').css('display', 'block')
                     //alert("here")

                 },
                 success: function(data) {
                     console.log(data)
                      $(".accordion").empty()
                     for (i = 0 ; i < data['res'].length; i++){

                       $(".accordion").append(
                         `<div class="card">
                           <div class="card-header p-2" id="headingOne">
                               <h5 class="mb-0">
                                   <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                     Q: `+data['res'][i]['question']+`
                                   </button>
                                 </h5>
                           </div>

                           <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#faqExample">
                               <div class="card-body">
                                   <b>Answer:</b> `+data['res'][i]['context']+`
                               </div>
                           </div>
                       </div>`
                     )


                     }
                 }


             });//ajax for question fetching









        });//event for pagination click


        $("body").on("mouseup", ".context", function() {

          setTimeout(function() {
              text = getSelectedText()
              if (text != "") {


                  $("#QuestionModal").modal()
                  $(".answer").html(text)
                  $("#update_ques").attr("filespace_id",$(".context").attr("filespace_id"))
                  $("#update_ques").attr("page_no",$(".context").attr("page_no"))

              }

          }, 1000)
        }); //answer updating on selecting the textt



        $("body").on("click","#update_ques",function(){
          var filespace_id = $(this).attr("filespace_id")
          var page_no = $(this).attr("page_no")
          var context = $(".answer").html()
          var question = $("#edit_question").val()
          console.log("question",question)
          var token = $('input[name$="csrfmiddlewaretoken"]').val();
          console.log(token)
          $.ajax({
    				type:"POST",
            headers: { "X-CSRFToken": token },
    				url:"/feedback/createQuestion",
    				data:{
              "filespace_id":filespace_id,
              "page_no":page_no,
              "context":context,
              "question":question
            },
    				success: function (data) {
    					if (data == "success" ){
    						//console.log(data)
    						//alert(data);
    						$("#snackbar").html("Created the Question Successfully")
    						$("#snackbar").addClass("show");
    						setTimeout(function(){ $("#snackbar").removeClass("show"); }, 3000);

    				}
    				else{

    					$("#snackbar").html("Question Creation failed")
    					$("#snackbar").addClass("show");
    					setTimeout(function(){ $("#snackbar").removeClass("show"); }, 3000);

    				}

    				},//success
    				error:function(){
    					$("#snackbar").html("some error occured")
    					$("#snackbar").addClass("show");
    					setTimeout(function(){ $("#snackbar").removeClass("show"); }, 3000);

    				}//error
    			});//ajax ends here



        })//add question


})//ready function
