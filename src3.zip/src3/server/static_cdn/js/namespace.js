$(document).ready(function() {

  $(".namespace").children('div').css("background-color", "#ea7db2") //mark the colour for current page

  $(".close-icon-left").on("click", function(e) {

    $(".add-docspace-panel").css({
      right: "-23%",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    });
    $(".left-pointer").css({
      display: "flex",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    })



  }) //close icon

  $(".left-pointer").on("click", function(e) {
    $(".left-pointer").css({
      display: "none",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    })
    $(".add-docspace-panel").css({
      right: "0%",
      transition: 'all 1s ease-in-out',
      WebkitTransition: 'all 1s ease-in-out'
    })


  }) //left pointer click

  $(".create-doc-space-form").submit(function(event) {
    event.preventDefault();
    $.ajax({
      type: "POST",
      url: "/namespace/create",
      data: $(".create-doc-space-form").serialize(),
      success: function(data) {

        if (data == "success") {
          $("#snackbar").html("Docspace creation successful refresing page now")
          $("#snackbar").addClass("show");
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);
          window.location.href = "/namespace?public=0"
        } else if (data == "duplicate") {
          $("#snackbar").addClass("show");
          $("#snackbar").html("Docspace already exists in the database please choose another name")
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);
        }



      }, //success
      error: function() {
        $("#snackbar").html("some error occured")
        $("#snackbar").addClass("show");
        setTimeout(function() {
          $("#snackbar").removeClass("show");
        }, 3000);

      } //error
    }); //ajax ends here


  }) //submit



  $(".expand").hover(
    function() {
      $(this).find(".namespace-options").css({
        "display": "block",
        transition: 'all 1s ease-in-out',
        WebkitTransition: 'all 1s ease-in-out'
      })
    },
    function() {
      $(this).find(".namespace-options").css({
        "display": "none",
        transition: 'all 1s ease-in-out',
        WebkitTransition: 'all 1s ease-in-out'
      })
    }
  ); //expand the folder options

  $("body").on("click", ".delete", function() {


    $.ajax({
      type: 'GET',
      url: "/namespace/delete?namespace_id=" + ($(this).attr("id")),
      beforeSend: function() {
        $('.loader').css('display', 'block')
      },
      success: function(data) {
        if (data == "success") {
          $("#snackbar").addClass("show");
          $("#snackbar").html("Doc Space " + $(this).attr("name") + " deleted sucessfully")
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);
          window.location.href = "/namespace?public=0"

        } else {
          $("#snackbar").addClass("show");
          $("#snackbar").html("Some error has happend")
          setTimeout(function() {
            $("#snackbar").removeClass("show");
          }, 3000);

        }

      } //success end

    }); //ajax end


  }); //delete end

  $("body").on("click",".rename",function(){

       var id = $(this).attr("id")
       console.log("#"+id+".doc_space_name")
       $("#"+id+".doc_space_name").attr("contenteditable","true").focus();

    });//rename
    $("body").on("keydown blur",".doc_space_name",function(e){
      if (e.keyCode == 13) {
            $(this).blur()
            name = $(this).text()
            id = $(this).attr("id")
            $(this).attr("contenteditable","false")
             $.get("/namespace/rename?namespace_id="+id+"&up_name="+name, function(data, status){
                if (data = "success"){
                  $("#snackbar").addClass("show");
                  $("#snackbar").html("Doc Space name updated sucessfully")
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);
                  window.location.href = "/namespace?public=0"
                }else{

                  $("#snackbar").addClass("show");
                  $("#snackbar").html("Some error has happend")
                  setTimeout(function() {
                    $("#snackbar").removeClass("show");
                  }, 3000);

                }

            });
        }

    });//rename enter event



      $(".dropdown-menu").on('click', 'a', function(){
        $(".dropdown").find(".btn:first-child").text($(this).text());
        $(".dropdown").find(".btn:first-child").val($(this).text());
        if($(this).text()=="Public"){
          window.location.href = "/namespace?public=1"

        }
        else{
          window.location.href = "/namespace?public=0"

        }



     });//drop down update event






}); //document ready
