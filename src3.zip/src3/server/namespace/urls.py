from django.contrib import admin
from django.urls import path
from .views import namespacePage,create,delete,rename

urlpatterns = [
    path('', namespacePage),
    path("/create",create),
    path("/delete",delete),
    path("/rename",rename)
]
