from django.apps import AppConfig


class NamespaceConfig(AppConfig):
    name = 'namespace'
